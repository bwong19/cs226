package hw9;

/**
 * Edge position for graph.
 * @param <T> Element type.
 */
public interface Edge<T> extends Position<T> {
}
