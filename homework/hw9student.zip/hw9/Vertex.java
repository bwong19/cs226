package hw9;

/**
 * Vertex position for graph.
 * @param <T> Element type.
 */
public interface Vertex<T> extends Position<T> {
}
